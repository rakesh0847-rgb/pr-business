# PR Business – Android Prototype

A simple offline-first starter app for:
- Invoice
- Income
- Expense
- Reports

## Open
Open this folder in Android Studio and let Gradle sync.

## Build APK
In Android Studio:
Build → Generate App Bundles or APKs → Generate APKs.

This prototype is the first UI/logic foundation. PDF invoice generation,
persistent Room database storage, invoice history, sharing/printing, and
automatic invoice numbering can be added in the next iteration.
