package com.prbusiness.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Entry(val type: String, val description: String, val amount: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PRBusinessApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PRBusinessApp() {
    var screen by remember { mutableStateOf("home") }
    var entries by remember { mutableStateOf(listOf<Entry>()) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("PR Business") })
            }
        ) { padding ->
            when (screen) {
                "invoice" -> InvoiceScreen(
                    modifier = Modifier.padding(padding),
                    onBack = { screen = "home" }
                )
                "income" -> EntryScreen(
                    title = "Add Income",
                    modifier = Modifier.padding(padding),
                    onBack = { screen = "home" },
                    onSave = { d, a ->
                        entries = entries + Entry("Income", d, a)
                        screen = "home"
                    }
                )
                "expense" -> EntryScreen(
                    title = "Add Expense",
                    modifier = Modifier.padding(padding),
                    onBack = { screen = "home" },
                    onSave = { d, a ->
                        entries = entries + Entry("Expense", d, a)
                        screen = "home"
                    }
                )
                "reports" -> ReportScreen(entries, Modifier.padding(padding)) {
                    screen = "home"
                }
                else -> HomeScreen(
                    entries = entries,
                    modifier = Modifier.padding(padding),
                    onInvoice = { screen = "invoice" },
                    onIncome = { screen = "income" },
                    onExpense = { screen = "expense" },
                    onReports = { screen = "reports" }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    entries: List<Entry>,
    modifier: Modifier,
    onInvoice: () -> Unit,
    onIncome: () -> Unit,
    onExpense: () -> Unit,
    onReports: () -> Unit
) {
    val income = entries.filter { it.type == "Income" }.sumOf { it.amount }
    val expense = entries.filter { it.type == "Expense" }.sumOf { it.amount }

    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Welcome to PR Business", style = MaterialTheme.typography.headlineSmall)
        Text("Balance: ₹%.2f".format(income - expense), style = MaterialTheme.typography.titleLarge)
        Button(onClick = onInvoice, modifier = Modifier.fillMaxWidth()) { Text("🧾  New Invoice") }
        Button(onClick = onIncome, modifier = Modifier.fillMaxWidth()) { Text("💰  Add Income") }
        Button(onClick = onExpense, modifier = Modifier.fillMaxWidth()) { Text("💸  Add Expense") }
        OutlinedButton(onClick = onReports, modifier = Modifier.fillMaxWidth()) { Text("📊  Reports") }
    }
}

@Composable
fun InvoiceScreen(modifier: Modifier, onBack: () -> Unit) {
    var customer by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var rate by remember { mutableStateOf("") }
    val total = (qty.toDoubleOrNull() ?: 0.0) * (rate.toDoubleOrNull() ?: 0.0)

    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("New Invoice", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(customer, { customer = it }, label = { Text("Customer Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(qty, { qty = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(rate, { rate = it }, label = { Text("Rate") }, modifier = Modifier.fillMaxWidth())
        Text("Grand Total: ₹%.2f".format(total), style = MaterialTheme.typography.titleLarge)
        Button(onClick = { /* PDF generation will be added in next build */ }, modifier = Modifier.fillMaxWidth()) {
            Text("Save Invoice")
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}

@Composable
fun EntryScreen(
    title: String,
    modifier: Modifier,
    onBack: () -> Unit,
    onSave: (String, Double) -> Unit
) {
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }

    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(description, { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = { amount.toDoubleOrNull()?.let { onSave(description, it) } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save") }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}

@Composable
fun ReportScreen(entries: List<Entry>, modifier: Modifier, onBack: () -> Unit) {
    val income = entries.filter { it.type == "Income" }.sumOf { it.amount }
    val expense = entries.filter { it.type == "Expense" }.sumOf { it.amount }

    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Reports", style = MaterialTheme.typography.headlineSmall)
        Text("Total Income: ₹%.2f".format(income))
        Text("Total Expense: ₹%.2f".format(expense))
        Text("Balance: ₹%.2f".format(income - expense))
        Divider()
        LazyColumn {
            items(entries) { e ->
                Text("${e.type}: ${e.description} — ₹%.2f".format(e.amount))
            }
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}
